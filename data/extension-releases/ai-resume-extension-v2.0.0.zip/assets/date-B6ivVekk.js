import{V as m}from"./index-CN3e6ejD.js";function s(r){if(!r)return"-";const t=m(r);return t.isValid()?t.format("YYYY-MM-DD HH:mm:ss"):"-"}export{s as f};
