import{T as r}from"./templateRegistry-DP8SKHdu.js";Object.fromEntries(r.map(m=>[m.id,m.name]));
